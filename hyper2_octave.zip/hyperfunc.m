function fval = hyperfunc (x)

% hyperbolic injection delta-v objective function

% required by hyper2_Octave.m

% Orbital Mechanics with OCTAVE

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global mu xinc rpmag vinfm ihat_inf v0 v1 dv

% unload current values for raan and true anomaly (radians)

raan = x(1);

tanom = x(2);

% compute ir1 unit vector

ihat_r1(1) = cos(raan) * cos(tanom) - sin(raan) * sin(tanom) * cos(xinc);

ihat_r1(2) = sin(raan) * cos(tanom) + cos(raan) * sin(tanom) * cos(xinc);

ihat_r1(3) = sin(tanom) * sin(xinc);

% compute itheta1 unit vector

ihat_theta1(1) = -cos(raan) * sin(tanom) - sin(raan) * cos(tanom) * cos(xinc);

ihat_theta1(2) = -sin(raan) * sin(tanom) + cos(raan) * cos(tanom) * cos(xinc);

ihat_theta1(3) = cos(tanom) * sin(xinc);

% compute ECI park orbit velocity vector (kilometers/second)

v0(1) = sqrt(mu / rpmag) * ihat_theta1(1);

v0(2) = sqrt(mu / rpmag) * ihat_theta1(2);

v0(3) = sqrt(mu / rpmag) * ihat_theta1(3);

% compute ECI injection hyperbola velocity vector (kilometers/second)

d = sqrt(1.0 + 4.0 * mu / (rpmag * vinfm^2 * (1.0 + dot(ihat_inf, ihat_r1))));

v1(1) = 0.5 * vinfm * ((d + 1.0) * ihat_inf(1) + (d - 1.0) * ihat_r1(1));

v1(2) = 0.5 * vinfm * ((d + 1.0) * ihat_inf(2) + (d - 1.0) * ihat_r1(2));

v1(3) = 0.5 * vinfm * ((d + 1.0) * ihat_inf(3) + (d - 1.0) * ihat_r1(3));

% compute impulsive delta-v vector (kilometers/second)

dv = v1 - v0;

% load scalar objective function - delta-v magnitude (kilometers/second)

fval = norm(dv);
