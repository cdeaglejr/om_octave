% hyper2_octave.m      December 10, 2013

% single impulse hyperbolic injection from a circular Earth park orbit

% NLP method with grid search, spherical Earth and two-body motion

% Orbital Mechanics with OCTAVE

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

global mu xinc rpmag vinfm rasc_asy ihat_inf v1 dv

% angular conversion factors

rtd = 180.0 / pi;

dtr = pi / 180.0;

% gravitational constant of the Earth (kilometers^3/second^2)

mu = 398600.4415;

% equatorial radius of the Earth (kilometers)

req = 6378.14;

% request user inputs

clc; home;

fprintf('\nhyper2.m - interplanetary injection from a circular Earth park orbit - NLP method');
fprintf('\n---------------------------------------------------------------------------------\n');

while (1)

   fprintf('\nplease input the altitude of the circular Earth park orbit (kilometers)\n');

   alt = input('? ');

   if (alt > 0.0)

      break;

   end

end

while (1)

   fprintf('\nplease input the orbital inclination of the Earth park orbit (degrees)');

   fprintf('\n(0 <= inclination <= 180)\n');

   orbinc = input('? ');

   if (orbinc >= 0.0 && orbinc <= 180.0)

      break;

   end

end

while (1)

   fprintf('\nplease input the C3 of the departure hyperbola (kilometers^2/second^2)');

   fprintf('\n(C3 > 0)\n');

   c3 = input('? ');

   if (c3 > 0.0)

      break;

   end

end

while (1)

   fprintf('\nplease input the right ascension of the outgoing asymptote (degrees)');

   fprintf('\n(0 <= right ascension <= 360)\n');

   rasc = input('? ');

   if (rasc >= 0.0 && rasc <= 360.0)

      break;

   end

end

while (1)

   fprintf('\nplease input the declination of the outgoing asymptote (degrees)\n');

   decl = input('? ');

   if (abs(decl) <= 90.0)

      break;

   end

end

% geocentric radius of park orbit (kilometers)

rpmag = req + alt;

% convert angular elements to radians

xinc = orbinc * dtr;

decl_asy = decl * dtr;

rasc_asy = rasc * dtr;

% v-infinity (kilometers/second)

vinfm = sqrt(c3);

% unit vector along the Earth's spin axis

pv = [0.0 0.0 1.0];

cdecl_asy = cos(decl_asy);

sdecl_asy = sin(decl_asy);

crasc_asy = cos(rasc_asy);

srasc_asy = sin(rasc_asy);

% compute unit asymptote vector

ihat_inf(1) = cdecl_asy * crasc_asy;

ihat_inf(2) = cdecl_asy * srasc_asy;

ihat_inf(3) = sdecl_asy;

% number of raan/true anomaly increments

nphi1 = 6;

nphi2 = 6;

% raan/true anomaly increments (radians)

dphi1 = 60.0 * dtr;

dphi2 = 60.0 * dtr;

% initial raan/true anomaly (radians)

phi01 = 0.0 * dtr;

phi02 = 0.0 * dtr;

% initialization

gdvmin = 1.0e99;

firstpass = 1;

% create two-dimensional grid

nsol = 0;

for i = 1:1:nphi1
    
    for j = 1:1:nphi2
        
        xg(1) = phi01 + dphi1 * (i - 1);
        
        xg(2) = phi02 + dphi2 * (j - 1);
        
        if (firstpass == 1)
            
            xg = xg';
            
            % bounds on control variables
            
            xlwr(1) = - 2.0 * pi;
            xupr(1) = + 2.0 * pi;
            
            xlwr(2) = - 2.0 * pi;
            xupr(2) = + 2.0 * pi;
            
            xlwr = xlwr';
            xupr = xupr';
            
        end
        
        % compute current solution
        
        [x, obj, info, iter, nf, lamda] = sqp(xg, 'hyperfunc', [], [], xlwr, xupr);
        
        x(1) = mod(x(1), 2.0 * pi);
        
        x(2) = mod(x(2), 2.0 * pi);
        
        nsol = nsol + 1;
        
        dvwrk(nsol) = obj;
        
        xwrk1(nsol) = x(1);
        
        xwrk2(nsol) = x(2);
        
    end
    
end

% find minimum delta-v solution

[dvmin, imin] = min(dvwrk);

dvsol1 = dvmin;

raan_sol1 = xwrk1(imin);

tanom_sol1 = xwrk2(imin);

if (abs(decl) < orbinc)
    
    % find second solution
    
    for i = 1:1:nsol
        
        % check difference in delta-v magnitude
        
        if (abs(dvsol1 - dvwrk(i)) <= 0.001)
            
            % check difference in park orbit raan
            
            if (abs(raan_sol1 - xwrk1(i)) <= 0.001)
                
                % null
                
            else
                
                dvsol2 = dvwrk(i);
                
                raan_sol2 = xwrk1(i);
                
                tanom_sol2 = xwrk2(i);
                
            end
            
        end
        
    end
    
end

% evaluate first solution

fsol = hyperfunc ([raan_sol1; tanom_sol1]);

% load classical orbital elements and compute state vector
% of park orbit at impulsive maneuver location

oev_po1(1) = rpmag;

oev_po1(2) = 0.0;

oev_po1(3) = xinc;

oev_po1(4) = 0.0;

oev_po1(5) = raan_sol1;

oev_po1(6) = tanom_sol1;

[rpo1, vpo1] = orb2eci(mu, oev_po1);

% state vector and orbital elements of hyperbola after maneuver

rhyper1 = rpo1;

vhyper1 = v1';

oev_hyper1 = eci2orb1 (mu, rhyper1, vhyper1);

clc; home;

fprintf('\n----------------------------------------------------------------------');
fprintf('\nInterplanetary Injection from a Circular Earth Park Orbit - NLP method');
fprintf('\n----------------------------------------------------------------------\n');

fprintf('\ndeparture hyperbola characteristics');
fprintf('\n-----------------------------------\n');

fprintf('\nc3                          %12.6f  kilometers^2/second^2\n', c3);

fprintf('\nasymptote right ascension   %12.6f  degrees\n', rtd * rasc_asy);

fprintf('\nasymptote declination       %12.6f  degrees\n', rtd * decl_asy);

fprintf('\n\norbital elements and state vector of park orbit at injection - opportunity #1');
fprintf('\n-----------------------------------------------------------------------------\n');

oeprint1(mu, oev_po1, 1);

svprint (rpo1, vpo1);

fprintf('\norbital elements and state vector of hyperbola at injection - opportunity #1');
fprintf('\n----------------------------------------------------------------------------\n');

oeprint1(mu, oev_hyper1, 1);

svprint (rhyper1, vhyper1);

fprintf('\ninjection delta-v vector and magnitude - opportunity #1');
fprintf('\n-------------------------------------------------------\n');

fprintf('\nx-component of delta-v      %12.6f  meters/second', 1000.0 * dv(1));

fprintf('\ny-component of delta-v      %12.6f  meters/second', 1000.0 * dv(2));

fprintf('\nz-component of delta-v      %12.6f  meters/second', 1000.0 * dv(3));

fprintf('\n\ndelta-v magnitude           %12.6f  meters/second\n', 1000.0 * norm(dv));

if (abs(decl) < orbinc)
    
    % opportunity #2 - evaluate second solution
    
    fsol = hyperfunc ([raan_sol2; tanom_sol2]);
    
    % load classical orbital elements and compute state vector
    % of park orbit at impulsive maneuver location
    
    oev_po2(1) = rpmag;
    
    oev_po2(2) = 0.0;
    
    oev_po2(3) = xinc;
    
    oev_po2(4) = 0.0;
    
    oev_po2(5) = raan_sol2;
    
    oev_po2(6) = tanom_sol2;
    
    [rpo2, vpo2] = orb2eci(mu, oev_po2);
    
    % state vector and orbital elements of hyperbola after maneuver
    
    rhyper2 = rpo2;
    
    vhyper2 = v1';
    
    oev_hyper2 = eci2orb1 (mu, rhyper2, vhyper2);
        
    fprintf('\n\norbital elements and state vector of park orbit at injection - opportunity #2');
    fprintf('\n-----------------------------------------------------------------------------\n');
    
    oeprint1(mu, oev_po2, 1);
    
    svprint (rpo2, vpo2);
    
    fprintf('\norbital elements and state vector of hyperbola at injection - opportunity #2');
    fprintf('\n----------------------------------------------------------------------------\n');
    
    oeprint1(mu, oev_hyper2, 1);
    
    svprint (rhyper2, vhyper2);
    
    fprintf('\ninjection delta-v vector and magnitude - opportunity #2');
    fprintf('\n-------------------------------------------------------\n');
    
    fprintf('\nx-component of delta-v      %12.6f  meters/second', 1000.0 * dv(1));
    
    fprintf('\ny-component of delta-v      %12.6f  meters/second', 1000.0 * dv(2));
    
    fprintf('\nz-component of delta-v      %12.6f  meters/second', 1000.0 * dv(3));
    
    fprintf('\n\ndelta-v magnitude           %12.6f  meters/second\n', 1000.0 * norm(dv));
    
end

fprintf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% create three-dimensional trajectory graphics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% orbital period of the park orbit

period_po1 = 2.0 * pi * sqrt(oev_po1(1)^3 / mu);

% unit asymptote vector

saxisx = [0 5 * ihat_inf(1)];
saxisy = [0 5 * ihat_inf(2)];
saxisz = [0 5 * ihat_inf(3)];

% ----------------------
% process opportunity #1
% ----------------------

dtof = 5000.0;

[ri_ho, vi_ho] = twobody2 (mu, -dtof, rhyper1, vhyper1);

deltat1 = period_po1 / 300.0;

simtime1 = -deltat1;

deltat2 = 2.0 * dtof / 300.0;

simtime2 = -deltat2;

for i = 1:1:301
    
    simtime1 = simtime1 + deltat1;
    
    simtime2 = simtime2 + deltat2;
    
    % park orbit "normalized" position vector
    
    [rf, vf] = twobody2 (mu, simtime1, rpo1, vpo1);
    
    rp1_x(i) = rf(1) / req;
    
    rp1_y(i) = rf(2) / req;
    
    rp1_z(i) = rf(3) / req;
    
    % hyperbolic orbit "normalized" position vector
    
    [rf, vf] = twobody2 (mu, simtime2, ri_ho, vi_ho);
    
    rp2_x(i) = rf(1) / req;
    
    rp2_y(i) = rf(2) / req;
    
    rp2_z(i) = rf(3) / req;
    
end

% create geocentric axes vectors

xaxisx = [1 1.5];
xaxisy = [0 0];
xaxisz = [0 0];

yaxisx = [0 0];
yaxisy = [1 1.5];
yaxisz = [0 0];

zaxisx = [0 0];
zaxisy = [0 0];
zaxisz = [1 1.5];

%%%%%%%%%%%%%%%%%%%%%
% geocentric graphics
%%%%%%%%%%%%%%%%%%%%%

figure (1);

hold on;

grid on;

% plot earth

[x y z] = sphere(24);

h = surf(x, y, z);

colormap([127/255 1 222/255]);

set (h, 'edgecolor', [1 1 1]);

% plot coordinate system axes

plot3(xaxisx, xaxisy, xaxisz, '-r', 'LineWidth', 1);

plot3(yaxisx, yaxisy, yaxisz, '-g', 'LineWidth', 1);

plot3(zaxisx, zaxisy, zaxisz, '-b', 'LineWidth', 1);

% plot unit asymptote vector

plot3(saxisx, saxisy, saxisz, '-m', 'LineWidth', 1.5);

% plot orbits

plot3(rp1_x, rp1_y, rp1_z, '-r', 'LineWidth', 1.5);

plot3(rp2_x, rp2_y, rp2_z, '-k', 'LineWidth', 1.5);

% label location of impulsive maneuver

plot3(rp1_x(1), rp1_y(1), rp1_z(1), 'or');

if (abs(decl) < orbinc)
    
    % ----------------------
    % process opportunity #2
    % ----------------------
    
    dtof = 5000.0;
    
    [ri_ho, vi_ho] = twobody2 (mu, -dtof, rhyper2, vhyper2);
    
    deltat1 = period_po1 / 300.0;
    
    simtime1 = -deltat1;
    
    deltat2 = 2.0 * dtof / 300.0;
    
    simtime2 = -deltat2;
    
    for i = 1:1:301
        
        simtime1 = simtime1 + deltat1;
        
        simtime2 = simtime2 + deltat2;
        
        % park orbit "normalized" position vector
        
        [rf, vf] = twobody2 (mu, simtime1, rpo2, vpo2);
        
        rp1_x(i) = rf(1) / req;
        
        rp1_y(i) = rf(2) / req;
        
        rp1_z(i) = rf(3) / req;
        
        % hyperbolic orbit "normalized" position vector
        
        [rf, vf] = twobody2 (mu, simtime2, ri_ho, vi_ho);
        
        rp2_x(i) = rf(1) / req;
        
        rp2_y(i) = rf(2) / req;
        
        rp2_z(i) = rf(3) / req;
        
    end
    
    % plot orbits
    
    plot3(rp1_x, rp1_y, rp1_z, '-r', 'LineWidth', 1.5);
    
    plot3(rp2_x, rp2_y, rp2_z, '-k', 'LineWidth', 1.5);
    
    % label location of impulsive maneuver
    
    plot3(rp1_x(1), rp1_y(1), rp1_z(1), 'or');
    
    % label plot
    
    xlabel('X coordinate (ER)', 'FontSize', 12);
    
    ylabel('Y coordinate (ER)', 'FontSize', 12);
    
    zlabel('Z coordinate (ER)', 'FontSize', 12);
    
end

axis equal;

% view(-57, 18);

view(106, 22);

rotate3d on;

% create color postscript graphics file with tiff preview

print -depsc -tiff -r300 hyper2.eps

